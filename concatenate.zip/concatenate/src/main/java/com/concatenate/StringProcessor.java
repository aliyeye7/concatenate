package com.concatenate;

public class StringProcessor {
    // 第一阶段：删除3个或更多连续相同的字符
    public String removeConsecutiveChars(String input) {
        String result = input;
        boolean changed;
        do {
            changed = false;
            StringBuilder sb = new StringBuilder();
            char[] chars = result.toCharArray();
            int count = 1;
            for (int i = 1; i < chars.length; i++) {
                if (chars[i] == chars[i - 1]) {
                    count++;
                } else {
                    if (count >= 3) {
                        changed = true;
                    } else {
                        for (int j = 0; j < count; j++) {
                            sb.append(chars[i - 1]);
                        }
                    }
                    count = 1;
                }
            }
            if (count < 3) {
                for (int j = 0; j < count; j++) {
                    sb.append(chars[chars.length - 1]);
                }
            }
            result = sb.toString();
        } while (changed);
        return result;
    }

    // 第二阶段：替换3个或更多连续相同的字符为前一个字母
    public String replaceConsecutiveChars(String input) {
        String result = input;
        boolean changed;
        do {
            changed = false;
            StringBuilder sb = new StringBuilder();
            char[] chars = result.toCharArray();
            int count = 1;
            for (int i = 1; i < chars.length; i++) {
                if (chars[i] == chars[i - 1]) {
                    count++;
                } else {
                    if (count >= 3) {
                        char replacement = (char) ((int) chars[i - 1] - 1);
                        if (replacement >= 'a') {
                            sb.append(replacement);
                            changed = true;
                        }
                    } else {
                        for (int j = 0; j < count; j++) {
                            sb.append(chars[i - 1]);
                        }
                    }
                    count = 1;
                }
            }
            if (count < 3) {
                for (int j = 0; j < count; j++) {
                    sb.append(chars[chars.length - 1]);
                }
            } else if (count >= 3) {
                char replacement = (char) ((int) chars[chars.length - 1] - 1);
                if (replacement >= 'a') {
                    sb.append(replacement);
                    changed = true;
                }
            }
            result = sb.toString();
        } while (changed);
        return result;
    }
}
